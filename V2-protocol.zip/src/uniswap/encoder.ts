

import { pack } from '@ethersproject/solidity'
import { FeeAmount } from '@uniswap/v3-sdk';
import { abi } from '@uniswap/universal-router/artifacts/contracts/UniversalRouter.sol/UniversalRouter.json'
import { PermitSingle } from '@uniswap/permit2-sdk'
import { Graph } from 'graph-data-structure'

import { IRouteInfoInResponse, ISwapResponse } from '../swapnet';
import { Interface, ethers } from 'ethers';
import { CommandType, RoutePlanner } from './routerCommands';
import { CONTRACT_BALANCE, ROUTER_AS_RECIPIENT, SENDER_AS_RECIPIENT } from './constants';

const universalRouterInterface: Interface = new Interface(abi);

export interface Permit2Permit extends PermitSingle {
  signature: string
}

const SIGNATURE_LENGTH = 65
const EIP_2098_SIGNATURE_LENGTH = 64
export const encodePermit = (planner: RoutePlanner, permit2: Permit2Permit): void => {
    let signature = permit2.signature

    const length = ethers.getBytes(permit2.signature).length
    // signature data provided for EIP-1271 may have length different from ECDSA signature
    if (length === SIGNATURE_LENGTH || length === EIP_2098_SIGNATURE_LENGTH) {
    // sanitizes signature to cover edge cases of malformed EIP-2098 sigs and v used as recovery id
    signature = ethers.Signature.from(ethers.Signature.from(permit2.signature)).serialized
    }

    planner.addCommand(CommandType.PERMIT2_PERMIT, [permit2, signature])
}

function encodeV3RouteToPath(inputTokenAddress: string, outputTokenAddress: string, feeAmount: FeeAmount): string {
    const types = ['address', 'uint24', 'address'];
    const path = [inputTokenAddress, feeAmount, outputTokenAddress];
  
    return pack(types, path)
}


export const encode = (swapResponse: ISwapResponse, slippageTolerance: number): { calldata: string } => {
    const graph = Graph();
    const tokenIndexToOutgoingRoutes: Map<number, IRouteInfoInResponse []> = new Map();

    swapResponse.routes.forEach(route => {
      graph.addEdge(route.fromTokens[0].index.toString(), route.toTokens[0].index.toString());
      const fromTokenIndex = route.fromTokens[0].index;
      if (!tokenIndexToOutgoingRoutes.has(fromTokenIndex)) {
        tokenIndexToOutgoingRoutes.set(fromTokenIndex, []);
      }
      tokenIndexToOutgoingRoutes.get(fromTokenIndex)!.push(route);
    });
    const sortedTokenIndexes = graph.topologicalSort().map(indexString => parseInt(indexString));

    // sortedTokenIndexes.forEach(sortedTokenIndex => console.log(swapResponse.tokens.find(token => token.index === sortedTokenIndex)?.symbol));
    // console.log(``)

    const costodyToCheckOutput = swapResponse.routes.map(route => route.toTokens[0].index === swapResponse.buy.index ? 1 : 0 as number).reduce((partialSum, a) => partialSum + a, 0) > 1;
    // const sellToken = swapResponse.tokens.find(token => token.index === swapResponse.sell.index)!;
    const buyToken = swapResponse.tokens.find(token => token.index === swapResponse.buy.index)!;

    const slippageToleranceMillionth = BigInt(Math.floor(slippageTolerance * 10 ** 6));
    const oneMillion = BigInt(10 ** 6);
    const minimumAmountOut = BigInt(swapResponse.buy.amount) * (oneMillion - slippageToleranceMillionth) / oneMillion;

    const planner = new RoutePlanner();

    sortedTokenIndexes.forEach(tokenIndex => {
        const routes = tokenIndexToOutgoingRoutes.get(tokenIndex);
        if (routes === undefined || routes.length === 0) {
            return;
        }
        routes.sort((r1, r2) => Number(BigInt(r1.fromTokens[0].amount) - BigInt(r2.fromTokens[0].amount)));
        routes.forEach((route, i) => {

            const fromToken = swapResponse.tokens.find(token => token.index === route.fromTokens[0].index)!;
            const toToken = swapResponse.tokens.find(token => token.index === route.toTokens[0].index)!;

            const payerIsUser = tokenIndex === swapResponse.sell.index;
            const recipientIsUser = !costodyToCheckOutput && route.toTokens[0].index === swapResponse.buy.index;
            const minAmountOut = recipientIsUser ? minimumAmountOut : 0n;
            let amountIn = BigInt(route.fromTokens[0].amount);
            if (!payerIsUser && i === routes.length - 1) {
                amountIn = CONTRACT_BALANCE;
            }

            // console.log(`${route.fromTokens[0].amount} ${fromToken.symbol} => ${route.toTokens[0].amount} ${toToken.symbol}`)

            if (route.name.startsWith("Uniswap")) {
                let commandType: CommandType;
                let path: string | string [];
                if (route.name.startsWith("Uniswap V2")) {
                    commandType = CommandType.V2_SWAP_EXACT_IN;
                    path = [ fromToken.address, toToken.address ]
                }
                else if (route.name.startsWith("Uniswap V3")) {
                    let feeAmount: FeeAmount;
                    commandType = CommandType.V3_SWAP_EXACT_IN;
                    if (route.name.search("100") >= 0) {
                        feeAmount = FeeAmount.LOWEST;
                    }
                    else if (route.name.search("500") >= 0) {
                        feeAmount = FeeAmount.LOW;
                    }
                    else if (route.name.search("3k") >= 0) {
                        feeAmount = FeeAmount.MEDIUM;
                    }
                    else if (route.name.search("10k") >= 0) {
                        feeAmount = FeeAmount.HIGH;
                    }
                    else {
                        throw new Error(`Unknown Uniswap V3 route name ${route.name}!`);
                    }
                    path = encodeV3RouteToPath(fromToken.address, toToken.address, feeAmount);
                }
                else {
                    throw new Error(`Unknown Uniswap route name ${route.name}!`);
                }

                planner.addCommand(commandType, [
                    recipientIsUser ? SENDER_AS_RECIPIENT : ROUTER_AS_RECIPIENT,
                    amountIn,
                    minAmountOut,
                    path,
                    payerIsUser,
                ]);
            }
            else if (route.name.startsWith("Curve V1")) {
                if (payerIsUser) {
                    planner.addCommand(CommandType.PERMIT2_TRANSFER_FROM, [
                        fromToken.address,
                        ROUTER_AS_RECIPIENT,
                        amountIn,
                    ]);
                }
                planner.addCommand(CommandType.CURVE_V1, [
                    route.address,
                    fromToken.address,
                    toToken.address,
                    amountIn,
                    minAmountOut,
                ]);
                if (recipientIsUser) {
                    planner.addCommand(CommandType.SWEEP, [
                        buyToken.address,
                        SENDER_AS_RECIPIENT,
                        minimumAmountOut,
                    ]);
                }
            }
            else {
                throw new Error(`Unknown route name ${route.name}!`);
            }
        });
    });

    if (costodyToCheckOutput) {
        // recipientIsUser === false holds for sure
        planner.addCommand(CommandType.SWEEP, [
            buyToken.address,
            SENDER_AS_RECIPIENT,
            minimumAmountOut,
        ]);
    }

    const { commands, inputs } = planner
    const calldata = universalRouterInterface.encodeFunctionData('execute(bytes,bytes[])', [commands, inputs])

    return { calldata };
}
