

const DEFAULT_GAS_PRICE = 20 * 1e9;
const getGasPriceFromOracleAsync = async (): Promise<number> => {
    try {
        const apikey = "AKWTJ9BAQTWWCF8Z6C4K29DSC1AMGT58BZ";
        const response = await fetch(`https://api.etherscan.io?module=gastracker&action=gasoracle&apikey=${apikey}`);

        if (response.status !== 200) {
            throw new Error(
                `Unexpected response code ${response.status} with body ${response.body}`
            );
        }
        const body = await response.json();
        if (
            body === undefined ||
            body.status !== "1" ||
            body.result === undefined ||
            body.result.ProposeGasPrice === undefined
        ) {
            throw new Error(`Unexpected response body ${JSON.stringify(body)}`);
        }

        const gasPrice = parseFloat(body.result.ProposeGasPrice) * 1e9;
        return gasPrice;
    } catch (e) {
        return DEFAULT_GAS_PRICE;
    }
}

export class GasManager {
    private _gasPriceRefreshTime: number = 0;
    private _gasPriceCached: number | Promise<number> = DEFAULT_GAS_PRICE;
    constructor() { }

    public async getGasPriceAsync(): Promise<number> {
        if (Date.now() - this._gasPriceRefreshTime > 12000) {
            if (!(this._gasPriceCached instanceof Promise)) {
                this._gasPriceCached = getGasPriceFromOracleAsync();
            }
            this._gasPriceCached = await this._gasPriceCached;
            this._gasPriceRefreshTime = Date.now();
        }
        return this._gasPriceCached;
    }
}

export const gasManager = new GasManager();