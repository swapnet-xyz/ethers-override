import { Network } from "ethers";
import { JsonRpcMultiCallProvider } from "../ethers-extensions/multicallProvider";


const rpcUrl = "https://eth-mainnet.g.alchemy.com/v2/4fN37iFyPnXDNP8M8tnPdW9BROFABoTp"
const network = { chainId: 1, name: "unknown" };
export const provider = new JsonRpcMultiCallProvider(
    rpcUrl,
    network,
    {
        staticNetwork: Network.from(network),
    }
);