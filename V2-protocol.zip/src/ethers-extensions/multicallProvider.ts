import { BlockTag, BytesLike, FetchRequest, Interface, JsonRpcApiProviderOptions, JsonRpcProvider, JsonRpcResult, Network, Networkish, ethers, makeError } from "ethers";
import { abi as multicall3Abi } from '../abi/multicall3.json'
import { EthCallOverride } from "./types";

const DEFAULT_GAS_PER_CALL = "50000";
type Timer = ReturnType<typeof setTimeout>;

const multicall3Interface: Interface = new Interface(multicall3Abi);
const multicall3Address = "0xcA11bde05977b3631167028862bE2a173976CA11";

interface ContractCall {
    to: string;
    data: BytesLike;
    gas?: string;
    from?: string;
    gasPrice?: string;
    value?: string;
};

type MulticallJsonRpcResult = JsonRpcResult & { multicallIndex?: number };

type ResolveFunc = (result: MulticallJsonRpcResult) => void;
type RejectFunc = (error: Error) => void;

type MutlicallPayload = {
    contractCall: ContractCall,
    blockTag: BlockTag,
    override: EthCallOverride | undefined,
    resolve: ResolveFunc,
    reject: RejectFunc,
};


type MulticallOptions = {
    multicallBatchStallTime?: number;
    multicallBatchMaxCount?: number;
    multicallBatchMaxGas?: bigint;
};

const defaultMulticallOptions: MulticallOptions = {
    multicallBatchStallTime: 4.5,     // 4.5ms
    multicallBatchMaxCount: 100,      // 100 requests
    multicallBatchMaxGas: 5000000n,
};

export class JsonRpcMultiCallProvider extends JsonRpcProvider {

    private readonly _options: MulticallOptions;
    private _multicallPayloads: Array<MutlicallPayload> = [];
    private _multicalDrainTimer: null | Timer = null;

    constructor(url?: string | FetchRequest, network?: Networkish, options?: JsonRpcApiProviderOptions & { multicall?: MulticallOptions }) {
        super(url, network, options);
        this._options = Object.assign({}, defaultMulticallOptions, options === undefined ? {} : options.multicall);
    }

    private _scheduleMulticallDrain(): void {
        if (this._multicalDrainTimer !== null) { return; }

        const multicallBatchMaxCount = this._options.multicallBatchMaxCount;
        const multicallBatchStallTime = this._options.multicallBatchStallTime!;
        const multicallBatchMaxGas = this._options.multicallBatchMaxGas!;

        // If we aren't using batching, no hard in sending it immeidately
        const stallTime = (multicallBatchMaxCount === 1) ? 0: multicallBatchStallTime;

        this._multicalDrainTimer = setTimeout(() => {
            this._multicalDrainTimer = null;

            const multicallPayloadsByBlockTag = this._multicallPayloads.reduce((group, call) => {
                const blockTag = call.blockTag.toString();
                group[blockTag] = group[blockTag] ?? [];
                group[blockTag].push(call);
                return group;
            }, {} as {[blockTag: string]: MutlicallPayload []});

            this._multicallPayloads = [];

            const batches: MutlicallPayload [][] = [];
            Object.values(multicallPayloadsByBlockTag).forEach((multicallPayloads) => {
                while (multicallPayloads.length) {
                    // Create payload batches that satisfy our batch constraints
                    const batch = [ <MutlicallPayload>(multicallPayloads.shift()) ];
                    while (multicallPayloads.length) {
                        if (batch.length === multicallBatchMaxCount) {
                            break;
                        }
                        batch.push(<MutlicallPayload>(multicallPayloads.shift()));

                        const totalEstimateGas = batch.map(p => BigInt(p.contractCall.gas??DEFAULT_GAS_PER_CALL)).reduce((acc, g) => acc + g, 0n);

                        if (totalEstimateGas > multicallBatchMaxGas) {
                            multicallPayloads.unshift(<MutlicallPayload>(batch.pop()));
                            break;
                        }
                    }
                    batches.push(batch);
                }
            });
    
            // Process the result to each payload
            (async () => {
                const dataAndTags = batches.map(batch => {
                    const multicallData = multicall3Interface.encodeFunctionData(
                        "tryAggregate", [
                            false,
                            batch.map(
                                ({ contractCall }) => [
                                    contractCall.to,
                                    contractCall.data
                                ]
                            )
                        ]
                    );
                    const multicallOverride = batch.reduce((result, payload) => {
                        if (payload.override !== undefined) {
                            return {...result, ...payload.override};
                        }
                        return result;
                    }, {})
                    return { multicallData, blockTag: batch[0].blockTag, multicallOverride };
                });

                this.emit("debug", { action: "sendMulticall", dataAndTags });

                await Promise.all(
                    dataAndTags.map(
                        async ({ multicallData, blockTag, multicallOverride, }, i) => {
                            try {
                                const result = await super.send(
                                    "eth_call",
                                    [
                                        {
                                            to: multicall3Address,
                                            data: multicallData,
                                        },
                                        blockTag,
                                        multicallOverride,
                                    ]);

                                // Find the matching result
                                // console.log(`result: ${result}`)
                                const resultsForMulticallBatch = multicall3Interface.decodeFunctionResult("tryAggregate", result);

                                for (let j = 0; j < batches[i].length; j++) {
                                    const { resolve, reject, contractCall } = batches[i][j];
                                    if (this.destroyed) {
                                        reject(makeError("provider destroyed; cancelled request", "UNSUPPORTED_OPERATION", { operation: "multicall" }));
                                        continue;
                                    }

                                    // No result; the node failed us in unexpected ways
                                    if (resultsForMulticallBatch === undefined || resultsForMulticallBatch === null || j >= resultsForMulticallBatch[0].length) {
                                        const error = makeError(`missing response for call #${j}`, "BAD_DATA", {
                                            value: result, info: { contractCall }
                                        });
                                        this.emit("error", error);
                                        reject(error);
                                        continue;
                                    }

                                    // All good; send the result
                                    // resolve({id: result.id, result: resultsForMulticallBatch[j], multicallIndex: j});
                                    // console.log(`result[j]: ${JSON.stringify(resultsForMulticallBatch)}`)
                                    resolve(resultsForMulticallBatch[0][j][1]);
                                }
                            } catch (error) {
                                for (const { reject } of batches[i]) {
                                    reject(error as any);
                                }
                            }
                        }
                    )
                )
            })();
        }, stallTime);
    }

    async send(method: string, params: Array<any> | Record<string, any>): Promise<any> {
        if (method !== "eth_call") {
            return await super.send(method, params);
        }

        let contractCall: ContractCall; 
        let blockTag: BlockTag = "latest";
        let override: EthCallOverride | undefined = undefined;
        let useSinglecall: boolean = false;
        if (Array.isArray(params)) {
            if (params.length === 0) {
                const error = makeError("missing eth_call parameters", "INVALID_ARGUMENT");
                this.emit("error", error);
                throw error;
            }
            contractCall = params[0];
            if (params.length > 1) {
                blockTag = params[1];
            }
            if (params.length > 2) {
                override = params[2];
            }
            if (params.length > 3) {
                useSinglecall = params[3];
            }
        }
        else {
            contractCall = params as ContractCall;
        }

        if (useSinglecall) {
            return await super.send(method, params.slice(0, 3));
        }

        const promise = new Promise((resolve, reject) => {
            this._multicallPayloads.push({ contractCall, blockTag, override, resolve, reject });
        });

        // If there is not a pending multicallDrainTimer, set one
        this._scheduleMulticallDrain();

        return promise;
    }
}

export const start = async () => {
    const network = { chainId: 1, name: "unknown" };
    const provider = new JsonRpcMultiCallProvider(
        "https://eth-mainnet.g.alchemy.com/v2/4fN37iFyPnXDNP8M8tnPdW9BROFABoTp",
        network,
        { staticNetwork: Network.from(network) }
    );
    const contract = new ethers.Contract(
        multicall3Address,
        multicall3Abi,
        provider
    );
    const blockNumber = await contract.getBlockNumber();
    const difficulty = await contract.getCurrentBlockDifficulty();
    console.log(`blockNumber: ${blockNumber}, ${difficulty}`);
}