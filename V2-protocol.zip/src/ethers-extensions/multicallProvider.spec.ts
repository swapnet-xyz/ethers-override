import { start } from "./multicallProvider";

test('adds 1 + 2 to equal 3', async () => {
    expect( 1 + 2).toBe(3);
    await start();
});
