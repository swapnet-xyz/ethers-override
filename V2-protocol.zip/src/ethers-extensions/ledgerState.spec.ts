
import { LedgerState } from "./ledgerState";
import { permit2 } from "./permit2AsIf";
import { tokenAt } from "./tokenAsIf";

test('adds 1 + 2 to equal 3', async () => {
    
    const tokenAddress: string = "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2";
    const ownerAddress: string = "0xe492fbc2df3998b25658c990c9e87b7d7a239839";
    const spenderAddress: string = "0x3fC91A3afd70395Cd496C647d5a6CC9D4B2b7FAD";
    const ownerBalance: bigint = 1000n;
    const allowance: bigint = 500n;

    const ledgerState = await LedgerState
                            .original
                            .asif(tokenAt(tokenAddress).balanceOf(ownerAddress).is(ownerBalance))
                            .asif(tokenAt(tokenAddress).balanceOf(ownerAddress).is(ownerBalance + 100n))
                            .asif(tokenAt(tokenAddress).allowance(ownerAddress, spenderAddress).is(allowance))
                            .asif(permit2.allowance(ownerAddress, tokenAddress, spenderAddress).is({ nonce: 1n, expiration: 0x6ac5e335n, amount: allowance}))
                            .getDiffAsync();

    console.log(JSON.stringify(ledgerState));
});
