
export interface ISwapRequest {
    chainId: number | undefined,
    userAddress: string | undefined,
    inputToken: string;
    outputToken: string;
    inputAmount: bigint;
    apiKey: string;
}

export interface ITokenAmountInfo {
    index: number;
    amount: string;
}

export interface ITokenInfoInResponse {
    index: number;
    address: string;
    name: string;
    symbol: string;
    decimals: number;
    usdPrice: number;
}

export interface IRouteInfoInResponse {
    address: string;
    name: string;
    fromTokens: Array<ITokenAmountInfo>;
    toTokens: Array<ITokenAmountInfo>;
}

export interface ISwapResponse {
    aggregator: string;
    nativeTokenUsdPrice: number;
    tokens: Array<ITokenInfoInResponse>;
    sell: ITokenAmountInfo;
    buy: ITokenAmountInfo;
    routes: Array<IRouteInfoInResponse>;
    calldata?: string;
    estimatedGas?: string;
}

// helper function
export const fromTokenUnits = (tokenUnits: number, decimals: number): bigint => {
    return 10n ** BigInt(decimals) * (BigInt(Math.round(tokenUnits * 1e18))) / BigInt(1e18);
}

export const toTokenUnits = (tokenAmount: bigint, decimals: number): number => {
    return Number(tokenAmount) / (10 ** decimals);
}